import React, { Component, createRef } from 'react'
import { Link } from 'react-router-dom'
import { connect } from 'react-redux'
import {
    HeaderWrapper,
    Logo,
    Nav,
    NavItem,
    NavSearch,
    Addition,
    Button,
    SearchWrapper,
    SearchInfo,
    SearchInfoTitle,
    SearchInfoSwitch,
    SearchInfoItem,
    SearchInfoList
} from './style'
import { searchFocus, searchBlur, getList, mouseEnter, mouseLeave, changePage } from './store/actionCreators'
import { loginOut } from '../../pages/login/store/actionCreators'

class Header extends Component {
    constructor (props) {
        super(props)
        this.icon=createRef()
    }
    render() {
        return (
            <HeaderWrapper>
                <Link to='/'><Logo /></Link>
                <Nav>
                    <NavItem className='left active'>首页</NavItem>
                    <NavItem className='left'>下载App</NavItem>
                    {
                        this.props.login
                        ?  
                        <NavItem className='right' onClick={this.props.loginOut}>退出</NavItem>
                        :   
                        <Link to='/login'><NavItem className='right'>登录</NavItem></Link>
                    }
                  
                    <NavItem className='right'>
                        <i className='iconfont'>&#xe636;</i>
                    </NavItem>
                    <SearchWrapper>
                        <NavSearch 
                            className={this.props.focused ? 'focused' : ''}
                            onFocus={this.props.getList.bind(this,this.props.list)}
                            onBlur={this.props.searchBlur.bind(this)}
                        ></NavSearch>
                        <i className={this.props.focused ? 'focused iconfont zoom' : 'iconfont zoom'}>&#xe60b;</i>
                        {this.getListArea()}
                    </SearchWrapper>
                </Nav>
                <Addition>
                    <Link to='/write'>
                        <Button className='writing'>
                            <i className='iconfont'>&#xe61c;</i>
                            写文章
                        </Button>
                    </Link>
                    <Button className='reg'>注册</Button>
                </Addition>
            </HeaderWrapper>
        )
    }

    getListArea() {
        const pageList = [];
        const newList = this.props.list.toJS();
        if(newList.length){    //因为页面加载之前newList是空数组 导致下面的key是undefined
            for(let i=(this.props.page-1)*10;i<this.props.page*10;i++){
                if(newList[i]){
                    pageList.push(<SearchInfoItem key={newList[i]}>{newList[i]}</SearchInfoItem>)
                }
            }
        }
        
        if(this.props.focused || this.props.mouseIn){
            return (
                <SearchInfo onMouseEnter={this.props.mouseEnter} onMouseLeave={this.props.mouseLeave}>
                    <SearchInfoTitle>
                        热门搜索
                        <SearchInfoSwitch onClick={()=>{
                            // // 解决this问题
                            // console.log(this.icon.current)
                            // const icon = this.icon.current
                            this.props.changePage(this.props.page,this.props.totalPage,this.icon.current)
                        }}>
                            <i className='iconfont spin' ref={this.icon}>&#xe851;</i>换一批
                        </SearchInfoSwitch>
                        <SearchInfoList>
                            {pageList}
                        </SearchInfoList>
                    </SearchInfoTitle>
                </SearchInfo>
            )
        }else{
            return ''
        }
    }
    
}
const mapStateToProps = (state) => {
    return {
        //下面两种一样
        // focused: state.get('headerReducer').get('focused')
        focused: state.getIn(['headerReducer','focused']),
        list: state.getIn(['headerReducer','list']),
        page: state.getIn(['headerReducer','page']),
        mouseIn: state.getIn(['headerReducer','mouseIn']),
        totalPage: state.getIn(['headerReducer','totalPage']),
        login: state.getIn(['loginReducer','login'])
    }
}

// const mapDispatchToProps = (dispatch) => {
//     return {
//         handleInputFocus(){
//             const action = {
//                 type:'search_focus'
//             }
//             dispatch(action)
//         },
//         handleInputBlur(){
//             const action = {
//                 type:'search_blur'
//             }
//             dispatch(action)
//         }
//     }
// }
// export default connect(mapStateToProps,mapDispatchToProps)(Header)
export default connect(mapStateToProps,{ searchFocus, searchBlur, getList, mouseEnter, mouseLeave, changePage, loginOut })(Header)
import headerReducer from './reducer'
export { headerReducer }
import * as actionType from './actionTypes'
import { fromJS } from 'immutable'

const initState = fromJS({
    //判断input是否聚焦
    focused: false,
    //判断鼠标是否划入推荐内容
    mouseIn:false,
    //ajax请求的推荐数据
    list:[],
    //推荐的当前页数
    page:1,
    //推荐的总页数
    totalPage:1
})
export default (state = initState, action) => {
     //immutable的set方法会结合之前的值和设置的值会返回一个全新的对象
    switch(action.type){
        case actionType.SEARCH_FOCUS:
            return state.set('focused',true)
        case actionType.SEARCH_BLUR:
            return state.set('focused',false)
        case actionType.CHANGE_LIST:
            // return state.set('list',action.data).set('totalPage',action.totalPage) 
            return state.merge({
                list: action.data,
                totalPage: action.totalPage
            })
        case actionType.MOUSE_ENTER:
            return state.set('mouseIn',true)
        case actionType.MOUSE_LEAVE:
            return state.set('mouseIn',false)
        case actionType.CHANGE_PAGE:
            if(action.payLoad.page<action.payLoad.totalPage){
                return state.set('page',action.payLoad.page+1)
            }else{
                return state.set('page',1)
            }
        default:
            return state
    }
}
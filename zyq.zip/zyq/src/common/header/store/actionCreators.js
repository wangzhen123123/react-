import * as actionType from './actionTypes'
import axios from 'axios'
import { fromJS } from 'immutable'

export const searchFocus = () => {
    return {
        type: actionType.SEARCH_FOCUS
    }
}

export const searchBlur = () => {
    return {
        type: actionType.SEARCH_BLUR
    }
}

const changeList = (data) => {
   return {
        type: actionType.CHANGE_LIST,
        data: fromJS(data),
        totalPage: Math.ceil(data.length / 10)
   }
}
export const getList = (list) => dispatch => {
        dispatch(searchFocus())
        //优化请求 防止请求重复的数据
        if(list.size === 0){
            axios.get('/api/headerList.json')
                .then( res => {
                    const data = res.data
                    dispatch(changeList(data.data))
                })
                .catch( err => {
                    console.log(err)
                })
        }
}

export const mouseEnter = () => {
    return {
        type: actionType.MOUSE_ENTER
    }
}

export const mouseLeave = () => {
    return {
        type: actionType.MOUSE_LEAVE
    }
}

export const changePage = (page, totalPage, spin) => {
    let rotateAngle = spin.style.transform.replace(/[^0-9]/ig,'');
    console.log(rotateAngle)
    if(rotateAngle){
        rotateAngle = parseInt(rotateAngle,10)
    }else{
        rotateAngle = 0
    }
    spin.style.transform = 'rotate('+(180+rotateAngle)+'deg)'
    return {
        type: actionType.CHANGE_PAGE,
        payLoad:{
            page,
            totalPage,
            spin
        }
    }
}
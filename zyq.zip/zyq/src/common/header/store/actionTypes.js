export const SEARCH_FOCUS = 'SEARCH_FOCUS'  //导航表单聚焦
export const SEARCH_BLUR = 'SEARCH_BLUR'    //导航表单失焦
export const CHANGE_LIST = 'CHANGE_LIST'    //导航推荐请求数据
export const MOUSE_ENTER = 'MOUSE_ENTER'    //导航推荐划入
export const MOUSE_LEAVE = 'MOUSE_LEAVE'    //导航推荐划出
export const CHANGE_PAGE = 'CHANGE_PAGE'    //导航推荐切换分页
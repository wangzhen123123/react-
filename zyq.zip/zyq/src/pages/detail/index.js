import React, { PureComponent } from 'react'
import { connect } from 'react-redux'
import { withRouter } from 'react-router-dom'
import {
    getDetail
} from './store/actionCreators'
import {
    DetailWrapper,
    DetailLeft,
    LeftWrapper,
    LeftTitle,
    LeftAuthor,
    LeftArticle
} from './style'

class Detail extends PureComponent {
    render() {
        return (
                <DetailWrapper>
                    <DetailLeft>
                        <LeftWrapper>
                            <LeftTitle>{this.props.title}</LeftTitle>
                            <LeftAuthor>
                                <a  href="/"><img src={this.props.authorUrl} alt="" /></a>
                                <div className='author-msg'>
                                    <span><a href="/">{this.props.author}</a></span>
                                    <button>关注</button>
                                </div>
                            </LeftAuthor>
                            <LeftArticle dangerouslySetInnerHTML={{__html:this.props.content}} />
                        </LeftWrapper>
                    </DetailLeft>
                </DetailWrapper>
        )
    }

    componentDidMount() {
        //请求detail数据
        this.props.getDetail(this.props.match.params.id)
    }
}

const mapState = state => {
    return {
        title: state.getIn(['detailReducer','list','title']),
        authorUrl: state.getIn(['detailReducer','list','authorUrl']),
        author: state.getIn(['detailReducer','list','author']),
        content: state.getIn(['detailReducer','list','content'])

    }
}
export default connect(mapState,{ getDetail })(withRouter(Detail))
import styled from 'styled-components'

export const DetailWrapper = styled.div`
    width:1000px;
    margin: 0 auto;
    padding: 10px 16px 100px 16px;
    overflow: hidden;
    // background: #f00;
`

export const DetailLeft = styled.div`
    width: 730px;
    margin-bottom: 24px;
    margin-right: 10px;
    float: left;
`
export const LeftWrapper = styled.div`
    background-color: #fff;
    border-radius: 4px;
    margin-bottom: 10px;
    padding: 24px;
`

export const LeftTitle = styled.h1`
    font-size: 30px;
    font-weight: 700;
    word-break: break-word;
    margin-bottom:15px;
`
export const LeftAuthor = styled.div`
    overflow:hidden;
    margin-bottom: 32px;
    a{
        text-decoration: none;
        outline: 0;
        display:block;
        float:left;
        img{
            display: block;
            border-radius: 50%;
            border: 1px solid #eee;
            min-width: 48px;
            min-height: 48px;
            width: 48px;
            height: 48px;
        }
    }
    .author-msg{
        display: inline-block;
        margin-left:8px;
        float:left;
        line-height:50px;
        span{
            font-size: 16px;
            font-weight: 500;
            margin-right: 8px;
            a{
                text-decoration: none;
                outline: 0;
                color: #000;
            }
        }
        button{
            color: #ec7259;
            background-color: #fef8f7;
            border-color: #ec7259;
            padding: 2px 9px;
            font-size: 12px;
            border-radius: 50px;
            outline: none;
        }
    }
    
`

export const LeftArticle = styled.div`
    img{
        width:100%;
        display:block;
        margin-bottom: 20px;
    }
    h1{
        font-size: 26px;
        margin-bottom: 16px;
        color: #404040;
        font-weight: 600;
    }
    p{
        margin-bottom: 20px;
        word-break: break-word;
        line-height: 30px;
        text-indent: 2em;
    }
`
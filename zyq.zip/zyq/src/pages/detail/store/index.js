import detailReducer from './reducer'
export { detailReducer }
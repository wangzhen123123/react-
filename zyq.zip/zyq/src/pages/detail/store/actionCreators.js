import axios from 'axios'
import * as actionTypes from './actionTypes'

const getDetailData = data => {
    return {
        type: actionTypes.GET_DETAIL_DATA,
        data
    }
}

export const getDetail = (id) => dispatch => {
    axios.get('/api/detail.json?id=' + id)
        .then(res => {
            const result = res.data.data
            dispatch(getDetailData(result))
        })
        .catch(err => {
            console.log(err)
        })
}
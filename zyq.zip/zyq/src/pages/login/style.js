import styled from 'styled-components'

export const LoginWrapper = styled.div`
    position: absolute;
    top:56px;
    left:0;
    right:0;
    bottom:0;
    background: #eeeeee;
`

export const LoginBox = styled.div`
    width: 400px;
    height: 250px;
    margin: 50px auto;
    background: #ffffff;
    padding-top:30px;
    border-radius: 4px;
    box-shadow: 0 0 8px rgba(0,0,0,.1);
`

export const Input = styled.input`
    width: 250px;
    height: 30px;
    line-height:30px;
    padding: 0 7px;
    display: block;
    color: #777777;
    margin: 20px auto;
`

export const Button = styled.div`
    width: 220px;
    height: 30px;
    line-height:30px;
    background: #3194d0;
    border-radius:15px;
    color: #ffffff;
    margin: 50px auto;
    text-align: center;
    cursor: pointer;
`
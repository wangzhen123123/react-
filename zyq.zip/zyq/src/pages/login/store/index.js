import loginReducer from './reducer'
export { loginReducer }
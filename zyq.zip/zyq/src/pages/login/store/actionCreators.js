import * as actionTypes from './actionTypes'
import axios from 'axios'

//登录验证
const changeLogin = (result) => {
    return{
        type: actionTypes.CHANGE_LOGIN,
        result
    }
}
export const login = (username,pwd) => dispatch => {
    axios.get('/api/login.json?username=' +username+ '&pwd=' + pwd)
        .then( res => {
            const result = res.data.data
            dispatch(changeLogin(result))
        })
        .catch(err => {
            console.log(err)
        })
}

export const loginOut = () => {
    return {
        type: actionTypes.LOGINOUT
    }
}
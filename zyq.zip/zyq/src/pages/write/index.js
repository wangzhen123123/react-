import React, { PureComponent, createRef } from 'react'
import { Redirect } from 'react-router-dom'
import { connect } from 'react-redux'

class Write extends PureComponent {
    constructor() {
        super()
        this.pwd = createRef()
        this.username = createRef()
    }
    render() {
        if( this.props.loginState ){
            return (
               <div>写文章页面</div>
            )
        }else{
            return (
                <Redirect to='/login' exact/>
            )
        }
        
    }
}

const mapState = state => {
    return {
        loginState: state.getIn(['loginReducer','login'])
    }
}
export default connect(mapState,null)(Write)

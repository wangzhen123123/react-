import React, { PureComponent } from 'react'
import { connect } from 'react-redux'
import { 
    Topic,
    List,
    Recommend,
    Writer
} from './components'
import {
    HomeWrapper,
    HomeLeft,
    HomeRight,
    BackTop
} from './style'
import { getHomeInfo, toggleTopShow } from './store/actionCreators'

class Home extends PureComponent {
    render() {
        return (
            <HomeWrapper>
                <HomeLeft>
                    <img className='banner-img'src="https://upload.jianshu.io/admin_banners/web_images/4961/8d89d11b3cecb28ade8757b6f509c31677e6ba80.jpg?imageMogr2/auto-orient/strip|imageView2/1/w/1250/h/540" alt="540" />
                    <Topic />
                    <List />
                </HomeLeft>
                <HomeRight>
                    <Recommend />
                    <Writer />
                </HomeRight>
                {/* 返回顶部 */}
                {
                    this.props.showScroll ? <BackTop onClick={this.handleScrollTop}>⇑</BackTop> : ''
                }
            </HomeWrapper>
        )
    }

    componentDidMount() {
        //获取home数据
        this.props.getHomeInfo()
        //判断滚动条位置
        // this.bindEvent()
        window.addEventListener('scroll',this.a)
    }

    componentWillUnmount() {
        window.removeEventListener('scroll',this.a)
    }

    a = () => {
        if(document.documentElement.scrollTop>400){
            this.props.toggleTopShow(true)
        }else{
            this.props.toggleTopShow(false)
        }
    }

    handleScrollTop = () => {
        window.scrollTo({
            top: 0,
            behavior: 'smooth',
        });
    }
}

const mapStateToProps = state => {
    return {
        showScroll: state.getIn(['homeReducer','showScroll'])
    }
}
export default connect(mapStateToProps,{ getHomeInfo, toggleTopShow })(Home)
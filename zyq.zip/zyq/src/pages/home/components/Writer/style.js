import styled from 'styled-components'

export const WriterWrapper = styled.div`
    width:278px;
    height:300px;
    // line-height:300px;
    // border: 1px solid #dcdcdc;
    // text-align: center;
`

export const DownLoad = styled.div`
    margin-bottom: 30px;
    padding: 10px 22px;
    width: 100%;
    border: 1px solid #f0f0f0;
    border-radius: 6px;
    background-color: #fff;
    box-sizing: border-box;
    overflow: hidden;
    position: relative;
    cursor: pointer;
    img{
        width: 60px;
        height: 60px;
        opacity: .85;
        display: inline-block;
    }
    .info{
        display: inline-block;
        margin-left: 7px;
        position:absolute;
        top:25px;
        h5{
            font-size: 15px;
            color: #333;
            padding-bottom: 5px;
        }
        p{
            margin-top: 4px;
            font-size: 13px;
            color: #999;
        }
    }
`

export const RecommendWrapper = styled.div`
    overflow:hidden;
    span{
        font-size: 14px;
        color: #969696;
        display:block;
        float:left;
    }
    .changeWriter{
        float: right;
        display: inline-block;
        font-size: 14px;
        color: #787878;
    }
`

export const WriterMsg = styled.div`
    margin-top: 15px;
    overflow: hidden;
    img{
        float: left;
        width: 48px;
        height: 48px;
        margin-right: 10px;
        border: 1px solid #ddd;
        border-radius: 50%;
    }
    .name{
        float: left;
        margin-left:10px;
        p{
            margin-top: 5px;
            padding: 0;
            font-size: 14px;
        }
        div{
            margin-top: 10px;
            font-size: 12px;
            color: #969696;
        }
    }
    .star{
        float:right;
        margin-top: 5px;
        padding: 0;
        font-size: 13px;
        color: #42c02e;
        cursor: pointer;
    }
`
    
export const FindMore = styled.div`
    width:100%;
    height: 36px;
    line-height: 36px;
    font-size: 13px;
    color: #787878;
    background-color: #f7f7f7;
    border: 1px solid #dcdcdc;
    border-radius: 4px;
    text-align: center;
    margin-top: 30px;
    cursor: pointer;
`
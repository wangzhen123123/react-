import React, { PureComponent } from 'react'
import { connect } from 'react-redux'
import { getAuthor } from '../../store/actionCreators'
import {
    WriterWrapper,
    DownLoad,
    RecommendWrapper,
    WriterMsg,
    FindMore
} from './style'


class Writer extends PureComponent {
    render() {
        return (
            <WriterWrapper>
                <DownLoad>
                    <img src="https://cdn2.jianshu.io/assets/web/download-index-side-qrcode-cb13fc9106a478795f8d10f9f632fccf.png" alt=""/>
                    <div className='info'>
                        <h5>下载简书手机App > </h5>
                        <p>随时随地发现和创作内容</p>
                    </div>
                </DownLoad>
                <RecommendWrapper>
                        <span>推荐作者</span>
                        <div className='changeWriter'>
                            <i className='iconfont' >&#xe851;</i> 换一批
                        </div>
                </RecommendWrapper>
                {
                    this.props.list.map(item => {
                        return (
                            <WriterMsg key={item.get('id')}>
                                <img src={item.get('imgUrl')} alt='' />
                                <div className='name'>
                                    <p>{item.get('title')}</p>
                                    <div>{item.get('desc')}</div>
                                </div>
                                <div className='star'>+关注</div>
                            </WriterMsg>
                        )
                    })
                }
                <FindMore>查看全部 ></FindMore>
            </WriterWrapper>
        )
    }
    componentDidMount() {
        this.props.getAuthor()
    }
}

const mapState = state => {
    return {
        list: state.getIn(['homeReducer','authorList'])
    }
}
export default connect(mapState,{getAuthor})(Writer)
import styled from 'styled-components'

export const RecommendWrapper = styled.div`
    margin:30px 0;
    width:280px;
`

export const RecommendItem = styled.div`
    width:280px;
    height:50px;
    margin-bottom: 6px;
    .recommend-pic{
        width: 100%;
        min-height: 50px;
        border-radius: 4px;
    }
`
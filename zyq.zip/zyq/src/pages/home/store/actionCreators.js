import axios from 'axios'
import * as actionTypes from './actionTypes'

//请求home数据
const changeHomeDate = res =>{
   return{
        type:actionTypes.GET_HOME_DATA,
        data:res
   }
}
export const getHomeInfo = () => dispatch => {
    axios.get('/api/home.json')
        .then(res=>{
            const result = res.data.data
            dispatch( changeHomeDate( result ) )
        })
        .catch(err=>{
            console.log(err)
        })
}

//加载更多
const addHomeList = (data,nextPage) => {
    return {
        type:actionTypes.GET_LIST_MORE,
        data,
        nextPage
    }
}

export const getMoreList = (page) => dispatch => {
    axios.get('/api/homeMore.json?page='+ page +'')
        .then(res=>{
            const result = res.data.data
            dispatch( addHomeList(result,page+1 ) )
        })
        .catch(err=>{
            console.log(err)
        })
}

//判断返回顶部是否显示
export const toggleTopShow = (flag) => {
    return {
        type:actionTypes.TOGGLE_SCROLL_SHOW,
        flag
    }
}

//请求右侧作者数据
const getAuthorDate = result => {
    return {
        type:actionTypes.GET_AUTHOR_DATA,
        result
    }
}

export const getAuthor = () => dispatch => {
    axios.get('/api/writer.json')
        .then(res => {
            const result = res.data.data.writerList
            dispatch(getAuthorDate(result))
        })
        .catch(err => {
            console.log(err)
        })
}
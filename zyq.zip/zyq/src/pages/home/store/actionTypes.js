export const GET_HOME_DATA = 'GET_HOME_DATA'   //获取home数据
export const GET_LIST_MORE = 'GET_LIST_MORE'   //点击加载更多
export const TOGGLE_SCROLL_SHOW = 'TOGGLE_SCROLL_SHOW' //返回顶部是否显示
export const GET_AUTHOR_DATA = 'GET_AUTHOR_DATA' //请求作者数据